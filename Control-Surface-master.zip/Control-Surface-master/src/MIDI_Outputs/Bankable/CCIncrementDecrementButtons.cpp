#ifdef TEST_COMPILE_ALL_HEADERS_SEPARATELY
#include "CCIncrementDecrementButtons.hpp"
#endif
