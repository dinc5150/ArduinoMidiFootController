#!/usr/bin/env sh
exec llvm-cov gcov "$@"