# Arduino Mock

This folder contains a mock version of the Arduino core.

It provides the standard Arduino API (`digitalWrite`, `millis`, `Serial` etc.)
with mocks that can be used during testing.